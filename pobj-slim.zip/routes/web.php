<?php

// Rotas web removidas - o Vue SPA agora cuida de todas as rotas não-API
// O public/index.php serve o dist/index.html do Vue para todas as rotas que não são /api/*
// 
// Se você ainda precisar de rotas Twig específicas no futuro, adicione-as aqui
// mas certifique-se de que elas não conflitem com as rotas do Vue